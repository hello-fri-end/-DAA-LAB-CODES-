#include<stdio.h>
#include "lab3.h"

void q1_insertionsort()
{
    //prompt for the array
    printf("Enter the size of the array:");
    int size;
    scanf("%d",&size);
    printf("Enter the elements of the array:\n");
    int arr[size];
    int temp;
    int i,j;
    for(i=0; i<size ; i++)
    {
        printf("Enter %dth element:",i);
        scanf("%d",&temp);

        for( j=0; j<i ;j++)
        {
            if(arr[j]>=temp && arr[j+1]!=temp)
            {
                for(int k=i; k>=j+1; k--)
                {
                    arr[k] = arr[k-1];
                }
                arr[j] = temp;
                break;
            }
        }
        if(j==i)
        arr[i] =temp;

    }


    for( i=0;i<size;i++)
    {
        printf("%d ", arr[i]);
    }
}
