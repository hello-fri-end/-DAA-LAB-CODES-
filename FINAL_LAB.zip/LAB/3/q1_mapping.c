#include<stdio.h>
#include "lab3.h"

void l3_mapping()
{
	int n;
	printf("enter the size of array\n");
	scanf("%d",&n);
	int i,j;
	int a[n],t=0,p=0,c=0;
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	int b[3][n];
	for(i=0;i<n;i++)
	{
		if(a[i]==0)
		{
			b[0][t]=0;
			t++;
		}
		else if(a[i]==1)
		{
			b[1][p]=1;
			p++;
		}
		else
		{
			b[2][c]=2;
			c++;
		}
	}
	for(j=0;j<t;j++)
		a[j]=b[0][j];
	for(j=0;j<p;j++)
		a[t+j]=b[1][j];
	for(j=0;j<c;j++)
		a[j+t+p]=b[2][j];
	printf("sorted array is\n");
	for(i=0;i<n;i++)
		printf("%d\t",a[i]);
	//return 0;
}
	
