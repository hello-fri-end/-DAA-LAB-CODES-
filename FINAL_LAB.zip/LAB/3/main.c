#include<stdio.h>
#include "lab3.h"

int main()
{
return(0);
}
