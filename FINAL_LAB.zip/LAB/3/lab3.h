void q1_insertionsort();
void l3_mapping();
void q1_mergesort();
