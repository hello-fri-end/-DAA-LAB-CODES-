//logic 3 - hcf of two numbers

#include<stdio.h>
#include<stdlib.h>
#include "gcd.h"
void gcd_3_itr()
{
	int a,b;
    printf("Enter a :");
	scanf("%d",&a);
	a = abs(a);

    printf("Enter b :");
	scanf("%d",&b);
	b = abs(b);
	int i=2,m=1;
	if(a==0 && b==0)
	{
	printf("HCF of the two numbers is infinity\n");
	//return 0;
	}
	else if(a==0 && b!=0)
	{
		printf("hcf is %d\n",b);
		//return 0;
	}
	else if(b==0 && a!=0)
	{
		printf("hcf is %d\n",a);
		//return 0;
	}
	else if(a==1 || b==1)
	{
		printf("hcf is %d\n",1);
		//return 0;
	}

	while(i<=a&&i<=b)
	{
		if(a%i==0&&b%i==0)
		{
			a=a/i;
			b=b/i;
			m=m*i;
		}
		else
		{
			i++;
		}
	}
	printf("HCF=%d\n",m);
	//return 0;
}
