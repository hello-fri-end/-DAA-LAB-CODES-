#include<stdio.h>
#include<stdlib.h>
#include "gcd.h"

int gcd2(int x,int y)
{
	if(x==0)
	return y;
	else if(y==0)
	return x;
	else if(x==1||y==1)
	return 1;
	else
	{
		return(gcd2(y,x%y));
	}
}
void gcd_2_gen()
{
	int a,b;
    printf("Enter a:");
	scanf("%d",&a);
    printf("Enter b:");
	scanf("%d",&b);
     int x=a,y=a;
    if(x>y)
     x= gcd2(a,b);
	else
       x = gcd2(b,a);
    int c=1;
    while(c!=0)
    {
        printf("Press 1 to continue and 0 to exit\n");
        scanf("%d",&c);
        if(c==0)
        {
            printf("HCF = %d\n", x);
            //return 0;
        }
        else
        {
            int c;
            printf("Enter a number:");
            scanf("%d", &c);
            if( x>c)
                x = gcd2(x,c);
            else
                x= gcd2(c,x);
            
        }
        
}
}
