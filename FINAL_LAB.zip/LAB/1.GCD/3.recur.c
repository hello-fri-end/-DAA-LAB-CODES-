//logic 3- gcd of two numbers
#include<stdio.h>
#include "gcd.h"


int abs(int a)
{
	if(a>=0)
	return(a);
	else
	return(-a);
}

int gcd1(int x,int y,int i)
{
	if(x==0 && y==0)
	{
	    printf("HCF is infinity!\n");
	    return(0);
	}
	else if(y==0 && x!=0)
	return x;
	else if(x==0 && y!=0)
	return y;
	else if(i>x||i>y)
	return(1);
	else if(x%i==0&&y%i==0)
	return(i*gcd1(x/i,y/i,i));
	else
	{
		i=i+1;
		gcd1(x,y,i);
	}
	return(-1);
}

void gcd_3_rec()
{
	int a,b;
    printf("Enter a :");
	scanf("%d",&a);
	a= abs(a);

    printf("Enter b:");
	scanf("%d",&b);
	b= abs(b);

	//int i=2;
	printf("HCF=%d\n",gcd1(a,b,2));
	//return 0;
}
