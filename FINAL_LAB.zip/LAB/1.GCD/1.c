//logic 1- GCD of two numbers
//starting from the smalller of the two numbers, the remainder with each number is calculated and when it becomes zero for both, that number is GCD

#include<stdio.h>
#include<stdlib.h>
#include "gcd.h"
void gcd_1_itr()
{
    //prompt for the numbers
    printf("Enter two numbers\n");

    printf("Enter a:\n");
    int a;
    scanf("%d",&a);
    a=abs(a);
    printf("Enter b:\n");
    int b;
    scanf("%d",&b);
    b=abs(b);
    int c = a>b ?b:a;
    int m=0;
    for( int i =c; i>0 ;i--)
    {
        if(a%c==0 &&b%c==0)
        {
            printf("The GCD of two numbers is %d\n", c);
            m=1;
            break;
        }
    }
    if(m==0)
    {
		if(a!=0)
		printf("The GCD of the two numbers is %d",a);
		else if(b!=0)
		printf("The GCD of the two numbers is %d",b);
		else
		printf("GCD of the given two numbers is infinity\n");
	}
}
