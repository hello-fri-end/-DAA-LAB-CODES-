#include<stdio.h>
#include "gcd.h"

int main()
{
	
	
  return(0);
}
