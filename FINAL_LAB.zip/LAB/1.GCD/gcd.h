/*
 *          File: gcd.h
 *        Authors: Shah Anwar khalid ,Haldhar dwivedi
 * Last Modified: April1, 2020
 *         Topic:gcd of 2 numbers in 3 logic with iterative and recursive implementation
 * ----------------------------------------------------------------
 *
 * OVERVIEW:
 * =========
 * This is the "interface" for the module that provides
 * gcd of 2 numbers
 *
 */


/************************ Function Prototypes *********************/
void gcd_1_itr();

void gcd_1_rec();

void gcd_2_itr();

void gcd_2_rec();

void gcd_3_itr();

void gcd_3_rec();

void gcd_2_gen();


