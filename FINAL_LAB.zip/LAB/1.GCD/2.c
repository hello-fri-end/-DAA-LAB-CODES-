//logic 2- GCD of two numbers
//using eulers equation

#include<stdlib.h>
#include<stdio.h>
#include "gcd.h"
void gcd_2_itr()
{
    //prompt for the numbers
    printf("Enter two numbers\n");

    printf("Enter a:");
    int a;
    scanf("%d",&a);
    a= abs(a);

    printf("Enter b:");
    int b;
    scanf("%d",&b);
    b = abs(b);

    int x= a>b ? b:a;
    int y = a>b? a:b;

    if(x==0)
    {
        if(a==0 && b==0)
        {
           printf("HCD of the two numbers is infinity\n");
        }
        else if(b==0 && a!=0)
              printf("HCF = %d\n" , a);
              else
                printf("HCF = %d\n" , b);
        //return 0;
    }

    while(1)
    {
        int z = y%x;
        if (z==0)
            break;
        else
        {
            y=x;
            x=z;

        }
    }
    if(a<0 && b<0)
    printf("HCF = %d\n" , -x);
    else
    printf("HCF= %d\n",x);
}

