//logic 2-recursive version of gcd using euler's eq

#include<stdio.h>
#include<stdlib.h>
#include "gcd.h"

int gcd3(int x,int y)
{
    if(x==0 && y==0)
   {
       printf("HCF of the two numbers is infinity\n");
       exit(0);
   }
    else if(x==0 && y!=0)
	return y;
	else if(y==0 && x!=0)
	return x;
	else if(x==1||y==1)
	return 1;
	else
	{
		return(gcd3(y,x%y));
	}
}

void gcd_2_rec()
{
	int a,b;
	printf("Enter a:");
	scanf("%d",&a);
	a = abs(a);
	printf("Enter b:");
	scanf("%d",&b);
	b= abs(b);
	if(a>b)
	printf("%d",gcd3(a,b));
	else
	printf("%d",gcd3(b,a));
}
