#include<stdio.h>
#include "lab4.h"

int main()
{
return(0);
}
