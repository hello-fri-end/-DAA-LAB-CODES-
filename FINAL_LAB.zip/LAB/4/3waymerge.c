#include<stdio.h>
#include<stdlib.h>
#include "lab4.h"

void mergesort1(int arr[], int start, int end);
int min1(int a1,int a2,int a3);
void merge1(int arr[], int start, int size, int end);

int min1(int a1,int a2,int a3)
{
	if(a2>a1)
		a2=a1;
	if(a2>a3)
		a2=a3;
		return(a2);
}

void merge1(int arr[], int start, int size, int end)
 {
    int size1 = size;
    int size2 = size;
    int size3 = end - 2 * size + 1;

    int arr1[size1], arr2[size2], arr3[size3];

    int i, j, k, t;

    for (i = start; i <= size - 1; i++)
      arr1[i - start] = arr[i];

    for (j = size; j <= 2 * size - 1; j++)
      arr2[j - size] = arr[j];

    for (k = 2 * size; k <= end; k++)
      arr3[k - 2 * size] = arr3[k];

    i = j = k = 0;
    t = start;

    while (i < size1 && j < size2 && k < size3)
      {
		int min = min1(arr1[i], arr2[j], arr3[k]);
		arr[t] = min;

		if (arr1[i] == min)
		i++;

		else if (arr2[j] == min)
		j++;
	
		else
		k++;

		t++;
      }
 }
 void mergesort1(int arr[], int start, int end)
  {
    if (end > start)
      {
		int size = (start + end + 1) / 3;
		mergesort1(arr, start, size - 1);
		mergesort1(arr, size, 2 * size - 1);
		mergesort1(arr, 2 * size, end);
		merge1(arr, start, size, end);
      }
  }
		
		

void threemerge()
{
    printf ("Enter the size of the array: ");
    int size;
    scanf ("%d", &size);

    int arr[size];
    printf ("Enter the elements of the array:\n");

    for (int i = 0; i < size; i++)
      {
	printf ("Enter %dth element:", i);
	scanf ("%d", &arr[i]);
      }
      mergesort1(arr, 0 ,size-1);
}
