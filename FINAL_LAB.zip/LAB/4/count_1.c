#include<stdio.h>

int counter=0;
void count_1(int arr[], int start , int end);
void count1_binary()
{
    printf("Enter the size of the array :");
    int size;
    scanf("%d",&size);

    int arr[size];
    for(int i=0;i<size;i++)
    {
        printf("Enter %dth element:",i);
        scanf("%d",&arr[i]);
    }
    count_1(arr,0,size-1);
    printf("Number of 1's entered is =%d\n",counter);


}
void count_1(int arr[], int start , int end)
{
    if(start==end)
    {
        if(arr[start]==1)
        counter++;
    }
    else
    {
        count_1(arr, (start+end)/2 +1,end);
        count_1(arr,start,(start+end)/2);
    }

}
