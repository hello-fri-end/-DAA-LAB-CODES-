#include<stdio.h>
#include<stdlib.h>
#include "lab4.h"
//queue
typedef struct node
{
    int data;
    struct node* nptr;
}node;


 node*towerA=NULL;  //tower A
 node*towerB=NULL;  //tower B
 node*towerC=NULL;  //tower C

 void push(int x, node**ptr);
 int pop(node**ptr);
 node* birth(int x);
 void display(node*ptr);
 void Towers_Of_Hanoi(node**ptr1,node**ptr2,node**ptr3,int size);
 
void hanoi()
 {
   printf("Enter no. of discs you'd like to set up on tower A:");
   int size;
   scanf("%d",&size);

   printf("Enter the diameters of the discs in descending order\n");
   int temp;
   for(int i=0;i<size;i++)
   {
       printf("Enter diameter of %dth disc:",i);
       scanf("%d",&temp);
        push(temp,&towerA);
   }

   Towers_Of_Hanoi(&towerA,&towerB,&towerC,size);
   printf("Displaying tower C:\n");
   display(towerC);
 }

 void Towers_Of_Hanoi(node**ptr1,node**ptr2,node**ptr3,int size)
 {
     if(size==1)
      push(pop(ptr1),(ptr3));
     else
     {
         Towers_Of_Hanoi(ptr1,ptr3,ptr2,size-1);
         Towers_Of_Hanoi(ptr1,ptr2,ptr3,1);
         Towers_Of_Hanoi(ptr2,ptr1,ptr3,size-1);

     }

 }











 void push(int x, node**ptr)
 {

    node* newnode = birth(x);
    if((*ptr)!=NULL)
    {
        node* temp = *ptr;
        while(temp->nptr!=NULL)
        temp= temp->nptr;

        temp->nptr = newnode;
    }
    else
    {
        *ptr = newnode;
    }


 }


node*birth(int x)
 {
     node* temp = (node*) malloc(sizeof(node));
     temp->data = x;
     temp->nptr = NULL;
     return temp;
 }

  int pop(node**ptr)
  {

      if((*ptr)!=NULL)
      {
          if((*ptr)->nptr!=NULL)
          {
              node* temp=*ptr;
   while((temp->nptr)->nptr!=NULL)
   temp= temp->nptr;

   int x= (temp->nptr)->data;

   temp->nptr=NULL;
   return x;
          }
          else
          {
              int x= (*ptr)->data;
              (*ptr)=NULL;
              return x;

          }
      }
      else
      exit(0);
  }


  void display(node*ptr)
  {
      while(ptr!=NULL)
      {
          printf("%d ",ptr->data);
          ptr= ptr->nptr;
      }
      printf("\n");
  }

