#include<stdio.h>
#include "lab4.h"

void mergesort3(int arr[],int start , int end);
void merge3(int arr[], int start, int middle, int end);


void twomergesort()
{
    printf("Enter the size of the array: ");
    int size;
    scanf("%d",&size);

    int arr[size];
    printf("Enter the elements of the array:\n");

    for(int i=0;i<size;i++)
    {
        printf("Enter %dth element:",i);
        scanf("%d",&arr[i]);
    }

    printf("The sorted array is:\n");
    mergesort3(arr,0,size-1);

    for(int j=0; j<size;j++)
    printf("%d ",arr[j]);

    printf("\n");


}

void mergesort3(int arr[],int start , int end)
{
    if(end>start)
    {
        int middle = (start+end)/2;
        mergesort3(arr,start,middle);
        mergesort3(arr,middle+1,end);
        merge3(arr, start, middle, end);
    }
}

void merge3(int arr[], int start, int middle, int end)
{
    //make two temp arrays and copy the sorted data into appropriate array
    int size1 = middle - start  +1;
    int size2 = end - middle;

    int arr1[size1], arr2[size2];

    int i,j,k;

    for (i = start; i <=middle; i++)
        arr1[i-start] = arr[i];
    for(j=middle+1; j<=end ; j++)
    arr2[j-(middle+1)] = arr[j];
    //compare corresponding elements of the temp arrays and put appropriate one in the origina array
    i=j=0;
    k= start;
    while(i<size1 && j<size2)
    {
        if(arr1[i]>=arr2[j])
        {
        arr[k] = arr2[j];
        j++;
        }
        else
        {
            arr[k] = arr1[i];
            i++;
        }
        k++;
    }

    //copy remaining elements of arr1, if any
    while(i<size1)
    {
        arr[k]= arr1[i];
        i++;
        k++;
    }

    //same for arr2
    while(j<size2)
    {
        arr[k]= arr2[j];
        k++;
        j++;
    }




}
