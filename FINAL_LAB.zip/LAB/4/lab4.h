void twomergesort();
void threemerge();
void count1_binary();
void coun_negative();
void general_gcd();
void q2_brueteforce();
void hanoi();
