#include<stdio.h>
#include "lab4.h"

int sum=0;
int b[1000]={-1};
int diff=-1;
void disp(int *a,int *d,int start,int end,int index,int r)
{
	if(index==r)
	{
		int j;
		int sum1=0;
		for(j=0;j<r;j++)
		{
			sum1=sum1+d[j];
		}
		if(sum-2*sum1<0)
			sum1=2*sum1-sum;
		else
			sum1=sum-2*sum1;
		if(diff==-1)
		{
			for(j=0;j<r;j++)
			{
				b[j]=d[j];
				diff=sum1;
			}
			//printf("\n");
		}
		else if(sum1<diff)
		{
			for(j=0;j<r;j++)
			{
				//printf("%d\t",d[j]);
				b[j]=d[j];
				diff=sum1;
			}
			//printf("\n");
		}
			
		return;
	}
	else
	{
		int j;
		for(j=start;j<=end&&end-j+1>=r-index;j++)
		{
			d[index]=a[j];
			disp(a,d,j+1,end,index+1,r);
		}
	}
}
	
void q2_brueteforce()
{
	int n;
	printf("enter n\n");
	scanf("%d",&n);
	int i;
	int arr[n];
	int data[n/2];
	printf("enter n array elements\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
		sum=sum+arr[i];
	}
	disp(arr,data,0,n-1,0,n/2);
	printf("one partiton is \n");
	for(i=0;i<n/2;i++)
		printf("%d\t",b[i]);
}
