#include<stdio.h>
#include<stdlib.h>
#include "lab4.h"

int Generalized_GCD(int arr[], int start , int end);
int gcd31(int x,int y);
void general_gcd()
{
    printf("Enter the size of the array :");
    int size;
    scanf("%d",&size);

    int arr[size];
    for(int i=0;i<size;i++)
    {
        printf("Enter %dth element:",i);
        scanf("%d",&arr[i]);
    }

    printf("GCD of the given numbers is %d\n",Generalized_GCD(arr,0,size-1));

}
int Generalized_GCD(int arr[], int start , int end)
{
    if(end==start+1 )
    {
        return gcd31(arr[start],arr[end]);
    }
    else if(start==end)
    {
        return arr[start];
    }
    else
    {
        int gcd1=Generalized_GCD(arr, (start+end)/2 +1,end);
        int gcd2= Generalized_GCD(arr,start,(start+end)/2);
        return gcd31(gcd1,gcd2);
    }

}

int gcd31(int x,int y)
{
    if(x==0 && y==0)
   {
       printf("HCF is undefined\n");
       exit(0);
   }
    else if(x==0 && y!=0)
	return y;
	else if(y==0 && x!=0)
	return x;
	else
	{
		return(gcd31(y,x%y));
	}
}

