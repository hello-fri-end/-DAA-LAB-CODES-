#include<stdio.h>
#include "lab4.h"

int counter1=0;
void count_2(int arr[], int start , int end);
void coun_negative()
{
    printf("Enter the size of the array :");
    int size;
    scanf("%d",&size);

    int arr[size];
    for(int i=0;i<size;i++)
    {
        printf("Enter %dth element:",i);
        scanf("%d",&arr[i]);
    }
    count_2(arr,0,size-1);
    printf("Number of negative numbers entered is =%d\n",counter1);


}
void count_2(int arr[], int start , int end)
{
    if(start==end)
    {
        if(arr[start]<0)
        counter1++;
    }
    else
    {
        count_2(arr, (start+end)/2 +1,end);
        count_2(arr,start,(start+end)/2);
    }

}
