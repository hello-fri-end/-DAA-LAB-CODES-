#include<stdio.h>
#include "lab5.h"

int main()
{
	q52();
return(0);
}
