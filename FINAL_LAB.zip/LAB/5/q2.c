#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include "lab5.h"

void merge51(int arr[], int start, int middle, int end);
void mergesort51(int start , int end, int arr[]);
void insertionsort51(int start, int end, int a[]);


void q52()
{
    //initilize thr random array
    int arr[1000000];
    int i;
    srand(time(0));
    for(i=0;i<1000000;i++)
    arr[i]= rand();

    mergesort51(0,999999,arr);

    for(i =0;i<1000000; i++)
    printf("%d ", arr[i]);
}
void mergesort51(int start , int end, int arr[])
{
    if( (end-start)/100000 == 0 )
    insertionsort51(start,end,arr);
    else
    {
        int middle = (start+end)/2;
        mergesort51(start,middle, arr);
        mergesort51(middle+1,end,arr);
        merge51(arr,start,middle,end);
    }
}



void insertionsort51(int start, int end, int a[])
{
    for(int i=start ; i<=end ; i++)
    {
        for(int j = i; j>=start ; j--)
        {
            if(a[i+1]>=a[j])
            break;

            else
            {
                if(j==start)
                {
                    //shift right and insert a[i+1] at jth position
                int temp = a[i+1];
                for(int k = i ; k>=j ; k-- )
                    a[k+1]= a[k];

                a[j]= temp;
                break;

                }

                else if (a[i+1]>a[j-1])
                {
                //shift right and insert a[i+1] at jth position
                int temp = a[i+1];
                for(int k = i ; k>=j ; k-- )
                    a[k+1]= a[k];

                a[j]= temp;
                break;
            }

        }
    }
}
}





void merge51(int arr[], int start, int middle, int end)
{
    //make two temp arrays and copy the sorted data into appropriate array
    int size1 = middle - start  +1;
    int size2 = end - middle;

    int arr1[size1], arr2[size2];

    int i,j,k;

    for (i = start; i <=middle; i++)
        arr1[i-start] = arr[i];
    for(j=middle+1; j<=end ; j++)
    arr2[j-(middle+1)] = arr[j];
    //compare corresponding elements of the temp arrays and put appropriate one in the origina array
    i=j=0;
    k= start;
    while(i<size1 && j<size2)
    {
        if(arr1[i]>=arr2[j])
        {
        arr[k] = arr2[j];
        j++;
        }
        else
        {
            arr[k] = arr1[i];
            i++;
        }
        k++;
    }

    //copy remaining elements of arr1, if any
    while(i<size1)
    {
        arr[k]= arr1[i];
        i++;
        k++;
    }

    //same for arr2
    while(j<size2)
    {
        arr[k]= arr2[j];
        k++;
        j++;
    }
}


