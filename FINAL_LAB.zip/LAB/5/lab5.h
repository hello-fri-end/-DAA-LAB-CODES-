void q52();
void kpointer();
void heapify();
void dandc();
void twoattime();
void bstree();
