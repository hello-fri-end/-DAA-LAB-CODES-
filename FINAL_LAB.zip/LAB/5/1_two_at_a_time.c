#include<stdio.h>
#include<stdlib.h>
#include "lab5.h"
void merge52(int *arr1,int *arr2,int arr[], int size1, int size2);
void twoattime()
{
    //prompt for number of arrays
   printf("How many sorted arrays do you want?: ");
   int k;
   scanf("%d",&k);

   int* arrays[k];  //pointers to k-arrays
   int sizes[k];   //sizes of the arrays

    //prompt for the sizes of the arrays
   int i;
   for(i=0;i<k;i++)
   {
       printf("Enter the size of %dth array:", i+1);
       scanf("%d",&sizes[i]);
   }

   //prompt for the elements of the arrays
   for(  i =0; i< k ; i++)
   {
       printf("Enter the elements of arr%d\n",i+1);

       int *index=NULL;
       //malloc space for it
       arrays[i] = (int *)malloc(sizes[i]);
       index = arrays[i];
       for(int j=0; j<sizes[i] ;j++)
        {
            printf("Enter %dth elementh: ",j);
            scanf("%d",index);
            index++;

        }
   }

   //calculate totalsize
   int size=0;
   for(i=0;i<k;i++)
    size = size + sizes[i];

    int arr[size];


    //merge two arrays at a time
    merge52(arrays[0],arrays[1], arr, sizes[0], sizes[1]);
    int tempsize = sizes[0] + sizes[1];

    for(i=2;i<k;i++)
    {
        merge52(arrays[i],arr, arr, sizes[i],tempsize);
        tempsize = tempsize + sizes[i];
    }


    //check
    for(i=0;i<size;i++)
    printf("%d ",arr[i]);

    printf("\n");


}

void merge52(int* arr1,int* arr2,int arr[], int size1, int size2)
{

    int i,j,k;

    //compare corresponding elements
    i=j=0;
    k= 0;
    while(i<size1 && j<size2)
    {
        if(*arr1>=*arr2)
        {
        arr[k] = *arr2;
        arr2++;
        j++;
        }
        else
        {
            arr[k] = *arr1;
            arr1++;
            i++;
        }
        k++;
    }

    //copy remaining elements of arr1, if any
    while(i<size1)
    {
        arr[k]= *arr1;
        arr1++;
        i++;
        k++;
    }

    //same for arr2
    while(j<size2)
    {
        arr[k]= *arr2;
        k++;
        arr2++;
        j++;
    }
}
