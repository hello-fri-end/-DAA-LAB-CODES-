#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lab6.h"

int main()
{
	printf("nthdwn");
	return(0);
}
