#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lab6.h"

void ksmallest61(int a[], int low, int high, int k);
int partition61(int a[],int low, int high);
void swap61(int *a, int*b);
void printarray61(int a[], int low, int high );

void ksmallmain()
{
    int arr[5]= {11,0,23,5,5};
    ksmallest61(arr,0,4,3);

}

void ksmallest61(int a[], int low, int high, int k)
{
    if(low<high)
    {
        int pi = partition61(a,low,high);
       

        if(pi==k+1 || pi==k)
        printarray61(a,low,k-1);
        

        else
        { 
            printarray61(a,low,pi);
            ksmallest61(a,pi+1,high,k-pi);
        }
    }
}

int partition61(int a[],int low, int high)
{
    int pivot = a[high];
    int smallwindow = low -1; //initializing small window

    for(int i=low; i<=high - 1; i++)
    {
        if(a[i]<=pivot)
        {
            smallwindow++;
            swap61(&a[i],&a[smallwindow]);
        }

    }

    swap61(&a[high],&a[smallwindow+1]);

    return smallwindow+1;
}
void swap61(int *a, int*b)
{
    int temp = *a;
    *a= *b;
    *b= temp;
}
void printarray61(int a[], int low,int high)
{
    for(int i=low;i<=high;i++)
    printf("%d  ",a[i]);
}
