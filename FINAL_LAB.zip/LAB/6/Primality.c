#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lab6.h"

void primality()
{
   printf("NO ALGO\n");
}
