#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lab6.h"

void quickSort62(int a[], int low, int high);
int partition62(int a[],int low, int high);
void swap62(int *a, int*b);
void printarray62(int a[], int n );

void qsort_ans()
{
    int arr[10]= {3,4,1,5,6,0,100,-10,5,1};
    quickSort62(arr,0,9);
    printarray62(arr,10);
}

void quickSort62(int a[], int low, int high)
{
    if(low<high)
    {
        int pi = partition62(a,low,high);
        quickSort62(a,low, pi -1);
        quickSort62(a,pi+1, high);
    }
}

int partition62(int a[],int low, int high)
{
    int pivot = a[high];
    int smallwindow = low -1; //initializing small window

    for(int i=low; i<=high - 1; i++)
    {
        if(a[i]<pivot)
        {
            smallwindow++;
            swap62(&a[i],&a[smallwindow]);
        }

    }

    swap62(&a[high],&a[smallwindow+1]);

    return smallwindow+1;
}
void swap62(int *a, int*b)
{
    int temp = *a;
    *a= *b;
    *b= temp;
}
void printarray62(int a[], int n )
{
    for(int i=0;i<n;i++)
    printf("%d ",a[i]);
}
