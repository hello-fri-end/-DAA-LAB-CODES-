void  binary();
void ksmallmain();
void primality();
void qsort_ans();
