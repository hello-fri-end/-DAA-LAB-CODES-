#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lab6.h"

void binary_converter(int binary[], int bits, int x);
void binary_mul (int binary[], int bits);

void binary()
{
    printf("Enter n:");
    int n;
    scanf("%d", &n);


     //no of bits in the binary number
     int bits = log(n) * 1.5 +1;
     //to store the binary no.
    int binary[bits];

 //convert to binary
  binary_converter(binary,bits,n);

 //square and display
  binary_mul(binary,bits);


}
void binary_converter(int binary[], int bits, int x)
{
    int counter =0;
    //divide by 2 until you get 0
    while(x!=0)
    {
         binary[bits - counter -1] = x % 2;
        x= x/2;
        counter++;
    }

}


void binary_mul (int binary[], int bits)
{
    //to store 1 bit muls
    int *bit_muls[bits];
    //final result
    int result[2*bits];

    int counter =0;
    //the bit to multiply in the current iteration
    int bit;

     //multiply 1 bit  at a time with appropriate padding and store in bit_muls
     while( counter!=bits)
     {
         bit = binary[bits-1-counter];

         //for mul and padding
         bit_muls[counter]= (int*) malloc(bits+(counter*4));

          int i=0;

          //padding with zero
          while(i!=counter)
         {

             *bit_muls[counter] = 0;
             bit_muls[counter]++;
             i++;
         }

        //padding is done, now multiply and store
         for( i=0; i<bits; i++)
         {
             *bit_muls[counter]=  bit * binary[bits-1-i];
             bit_muls[counter]++;
         }
         bit_muls[counter]--;




         counter++;
     }




     int sum =0;
     int carry =0;

     //add the final bit muls
     //outerloop: adding corresponding bits in bitmuls
     for(int i=0;i<2*bits; i++)
     {
         //initiliz sum with carry
         sum=carry;

      //inner loop : adding one bit at a time
     for(int j=0; j<bits;j++)
     {
         if(-bits-j+1+i<=0)
         sum = (sum + *(bit_muls[j] - bits - j + i +1) );
     }

        if(sum>1)
         {
             carry= sum/2;
             sum = sum %2;
         }
         else
        carry =0;

     result[2*bits - i -1] = sum;




}

for(int i=0; i<2*bits; i++)
printf("%d", result[i]);

printf("\n");
}
