#include<stdio.h>
#include<stdbool.h>
bool binary_search(int x, int arr[],int size);
void q1_binary()
{
    //prompt for the array
    printf("Enter the size of the array:");
    int size;
    scanf("%d",&size);
    printf("Enter the elements of the array:\n");
    int arr[size];
    int temp;
    int i,j,m=0;
    for(i=0; i<size ; i++)
    {
        printf("Enter %dth element:",i);
        scanf("%d",&temp);

        for( j=0; j<i ;j++)
        {
            if(arr[j]>temp )
            {
                for(int k=i; k>=j+1; k--)
                {
                    arr[k] = arr[k-1];
                }
                arr[j] = temp;
                break;
            }
        }
        if(j==i)
        arr[i] =temp;
         }


            //prompt for r
            printf("Enter r:");
            int r;
            scanf("%d",&r);

         //for every element p in the array, using binary search check to see if r-p is present
         for( i=0;i<size;i++)
         {
             if(binary_search(r-arr[i],arr,size)==true)
             {
                 printf("Yes! There exists p and q in the array such that p +q = r\n");
                 printf("p = %d and q= %d\n",arr[i],r-arr[i]);
                  m=1;
                 break;
                 //return 0;
             }
         }
		if(m==0)
         printf("No! there doesn't exist p and q in the array such that p+q=r\n");
}

bool binary_search(int x, int arr[],int size)
{
    int beg=0;
    int end=size-1;
    int middle;
    while(beg<=end)
    {
        middle = (beg+end)/2;
        if(arr[middle]==x)
        return true;
        else if(arr[middle]>x)
        end = middle - 1;
        else
        beg = middle + 1;
    }
    return false;
}
