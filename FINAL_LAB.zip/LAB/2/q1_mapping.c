#include<stdio.h>
#include "lab2.h"
void q1_map()
{
    //prompt for the array
    printf("Enter the size of the array:");
    int size;
    scanf("%d",&size);
    printf("Enter the elements of the array:\n");
    int arr[size];
    for(int i=0; i<size ; i++)
    {
        printf("Enter %dth element:",i);
        scanf("%d",&arr[i]);
    }

    //prompt for the number r
    printf("Enter the number r:");
    int r;
    scanf("%d",&r);
	int m=0;
    //find the max and min of the array
    //needed only to make the logic work for negative numbers
    int max=arr[0];
    int min=arr[0];
    for(int i=1; i<size ; i++)
    {
     if(arr[i]>max)
     max = arr[i];

     if(arr[i]<min)
     min = arr[i];
    }

    //to make the logic work for negative numbers
    if(min<0)
    {
        r = r - min -min;
        for(int i=0;i<size; i++)
        arr[i]= arr[i] - min;


    int mapped_array[max-min+1];
    //initilize the array to 0
    for(int i=0;i<max-min+1;i++)
    mapped_array[i] = 0;

    //map old array to new
    for(int i=0;i<size;i++)
        mapped_array[arr[i]]++;

    //search for p,q
    for( int i=0; i<max-min+1 ; i++)
    {
        if(mapped_array[i]>=1)
        {
            //to deal with duplicate enteries
            if(r-i==i)
            {
            if(mapped_array[r-i]>=2)
            {
                printf("Yes, there exist p and q such that p+q=r\n");
                printf("p=%d and  q = %d\n", i+min,r-i+min);
                m=1;
                break;
                //return 0;
            }
            }
            else
            {
                if((r-i)<max-min+1 && mapped_array[r-i]>=1)
            {
                printf("Yes, there exist p and q such that p+q=r\n");
                printf("p=%d and  q = %d\n", i+min,r-i+min);
                m=1;
                break;
               // return 0;
            }

            }

        }
    }

    }
    else
    {
        int mapped_array[max+1];
        for(int i=0;i<max+1;i++)
        mapped_array[i]=0;

        //map old array to new
        for(int i=0;i<size;i++)
        mapped_array[arr[i]]++;

        //search for p and q

        for( int i=0; i<max+1 ; i++)
    {
         if(mapped_array[i]>=1)
        {
            //to deal with duplicate enteries
            if(r-i==i)
            {
            if(mapped_array[r-i]>=2)
            {
                printf("Yes, there exist p and q such that p+q=r\n");
                printf("p=%d and  q = %d\n", i,r-i);
                m=1;
                break;
                //return 0;
            }
            }
            else
            {
                if((r-i)<max+1 && mapped_array[r-i]>=1)
            {
                printf("Yes, there exist p and q such that p+q=r\n");
                printf("p=%d and  q = %d\n", i,r-i);
                m=1;
                break;
                //return 0;
            }

            }

        }


    }
    }
    if(m==0)
    printf("NO! There doesn't exist p and q such that p+q=r\n");
}
