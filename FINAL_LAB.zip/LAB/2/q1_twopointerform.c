#include<stdio.h>
#include "lab2.h"

int search(int ptr1,int ptr2,int arr[],int num);
int p,q;

void q1_twopointer()
{
	int n,r;
	printf("enter the size\n");
	scanf("%d",&n);
	int i;
	int a[n];
	int swap;
	printf("enter array elem\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		int j;
		for(j=0;j<i;j++)
		{
			if(a[j]>a[i])
			{
				swap=a[j];
				a[j]=a[i];
				a[i]=swap;
			}
		}
	}
	printf("enter the num r\n");
	scanf("%d",&r);
	int c=0;
	c=search(0,n-1,a,r);
	if(c==1)
	printf("PAIR FOUND AS %d and %d\n",p,q);
	else
	printf("PAIR NOT FOUND\n");
	//return 0;
}

int search(int ptr1,int ptr2,int arr[],int num)
{
	if(ptr1>ptr2)
	return 0;
	else if(arr[ptr1]+arr[ptr2]==num)
	{
		p=arr[ptr1];
		q=arr[ptr2];
		return(1);
	}
	else if(arr[ptr1]+arr[ptr2]>num)
	{
			ptr2--;
			search(ptr1,ptr2,arr,num);
	}
	else
	{
		ptr1++;
		search(ptr1,ptr2,arr,num);
	}
}
		
