#include<stdio.h>
void q3()
{
    printf("Enter n: ");
    int n;
    scanf("%d",&n);


     printf("PATTERN 1\n");
    //for pattern 1
    for(int i=1;i<=n;i++)
    {
    for(int j=1;j<=n-i+1;j++)
    {
        printf("%d ",j);
    }
    printf("\n");
    }

    printf("\n");

     printf("PATTERN 2\n");
    //for pattern 2
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<i;j++)
        {
            printf(" ");
        }
          for(int k=i+1;k<n+1;k++)
          printf("%d",k);
      printf("\n");
    }
    printf("\n");

    printf("PATTERN 3\n");
    //for pattern 3
    for(int i=0;i<n;i++)
    {
        for(int j=1;j<i+2;j++)
        printf("%d",j);
    printf("\n");
    }
    printf("\n");

    printf("PATTERN 4\n");
    //for pattern 4
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n-i-1;j++)
        printf(" ");

      for(int k=n-i; k<n+1;k++)
      printf("%d",k);

    printf("\n");
    }
    printf("\n");

    printf("PATTERN 5\n");
    //for pattern 5
    //upper part
    int j,i;
    for( i=0;i<n/2;i++)
    {
        for(int k=0;k<i;k++)
        printf(" ");

    for(j=i+1;j<n+1-i;j++)
    printf("%d",j);

    printf("\n");
    }



   //lower part
   for(i=0;i<n/2;i++)
   {
       for(int k=0;k<n/2-1-i;k++)
       printf(" ");

    for(j=n/2 -i; j<=n/2+1+i ; j++)
    printf("%d",j);

    printf("\n");
   }

}
