#include<stdio.h>

#include "lab2.h"

int a[10000];
int fibonacci ( int i);
int BinSearch(int * arr, int l, int h, int data);
void q2_fibonacci()
{
    //prompt for the array
    printf("Enter the elements of the array:\n");

    int i=0;
    while(1)
    {
        printf("Enter %dth element:",i);
        scanf("%d",&a[i]);
        if(a[i]== -1)
        break;
        else
         i++;

    }
    //initilize the rest to -1
    for(int j= i+1 ; j<10000 ;j++)
    a[j]= -1;


    //search for first -1 index using fibonacci jump
    i=0;  //iterations
    int fib_index=0; //array index
    while(1)
    {

    if(a[fib_index]==-1)
        {
          if(a[fib_index - 1]!=-1)
          {
              printf("the first occurence of -1 is at %d\n",fib_index);
              break;
             // return 0;
          }
          else
          {
              printf("The first occurence of -1 is at %d\n",BinSearch(a,fibonacci(i-1), fib_index, -1));
              break;
            //  return 0;
          }

        }
        else
        {
            i++;
            fib_index = fibonacci(i);
        }
    }
}
int fibonacci ( int i)
{
    if(i==0 || i==1)
    return 1;
    else
    return fibonacci(i-1) + fibonacci(i-2);
}

int BinSearch(int * arr, int l, int h, int data)
{
	if(l>h)
		return 0;
int mid;
	mid = (l+h) / 2;
	if(arr[mid] == data)
	{
		if(arr[mid-1] != data)
			return mid;
		else
			return BinSearch(arr, l, mid-1, data);
	}
	else
		return BinSearch(arr, mid+1, h, data);
}
