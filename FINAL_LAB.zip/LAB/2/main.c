#include<stdio.h>
#include "lab2.h"

int main()
{
return(0);
}
