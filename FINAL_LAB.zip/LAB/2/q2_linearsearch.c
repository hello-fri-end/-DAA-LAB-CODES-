//logic 1 : using linear search to find first -1
#include<stdio.h>
#include "lab2.h"

int a[10000];
void q2_linearseach()
{
    int c=1;
    int i=0;
    while(c!=0)
    {
        printf("Enter an element:");
        scanf("%d",&a[i]);
        if(a[i-1]==-1 && a[i]!=-1)
        {
            while(a[i]!=-1)
            {
            printf("Not allowed!\n You can only enter -1 now!\n");
            //reprompt
            printf("Enter -1:");
            scanf("%d",&a[i]);
            }
        }
        else
        {
        i++;
        printf("Enter 1 to continue and 0 to exit:");
        scanf("%d",&c);
    }}


   //linear search for -1
   int j=0;
   while(1)
   {
       if(a[j]==-1)
       {
           printf("first -1 is present at %d position\n",j);
           break;
       }
       else
       j++;

   }
}
