void q1_binary();
void q1_map();
void q2_fibonacci();
void q2_linearseach();
void q3();
void q1_twopointer();
